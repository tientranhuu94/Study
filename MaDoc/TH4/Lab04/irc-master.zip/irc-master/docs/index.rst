.. irckit documentation master file, created by
   sphinx-quickstart on Sat Apr 21 10:39:40 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

irckit
======

tinkering with a made-from-scratch irc library in python


Contents:

.. toctree::
   :maxdepth: 3
   :glob:

   installation
   example
   botnet


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

